# Text Representation — BoW, TF-IDF, Word Embeddings

## 🧠 Problem Statement
Explore and compare different methods of converting text into numerical features for use in machine learning models.

## 🔧 Approach & Methodology
- Preprocessed text using tokenization, stopword removal, and lemmatization.
- Implemented:
  - **Bag-of-Words (BoW)** using `CountVectorizer`.
  - **TF-IDF** using `TfidfVectorizer`.
  - **Word Embeddings** using pre-trained GloVe vectors.
- Compared vector dimensionality, sparsity, and semantic representation.

## 📈 Results & Evaluation
- TF-IDF captured term importance better than BoW.
- Word embeddings preserved semantic similarity between words.
- Dense vectors (embeddings) improved semantic tasks but required more resources.

## ✅ Learning Outcomes
- Understood pros/cons of BoW, TF-IDF, and embeddings.
- Learned how representation impacts downstream ML.

## 📦 Requirements
- Root `requirements.txt`
- Optional: `gensim` for embeddings

## ▶️ How to Run
Open `tfidf_bow_embeddings.ipynb` and execute all cells.  
Place example text files in `sample_data/`. Generated outputs will appear in the `outputs/` folder.
