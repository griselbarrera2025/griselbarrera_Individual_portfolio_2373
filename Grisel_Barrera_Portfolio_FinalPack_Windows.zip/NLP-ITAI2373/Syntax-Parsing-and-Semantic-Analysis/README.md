# Syntax Parsing & Semantic Analysis

## 🧠 Problem Statement
Analyze grammatical structure and meaning of text using POS tagging, dependency parsing, and entity recognition.

## 🔧 Approach & Methodology
- Used **spaCy** for POS tagging, dependency parsing, and NER.
- Explored token attributes: `.lemma_`, `.dep_`, `.head`, `.ent_type_`.
- Visualized dependency trees.

## 📈 Results & Evaluation
- Extracted entities with correct semantic roles.
- Dependency trees identified subject–verb–object relations.

## ✅ Learning Outcomes
- Applied modern NLP pipelines for syntactic and semantic analysis.

## 📦 Requirements
- Root `requirements.txt`
- Download spaCy model:
```bash
python -m spacy download en_core_web_sm
```

## ▶️ How to Run
```bash
python syntax_semantic.py
```
Outputs will be stored in the `outputs/` folder.
