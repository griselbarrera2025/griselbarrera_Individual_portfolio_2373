# Intro to Audio & Preprocessing (MFCCs)

## 🧠 Problem Statement
Prepare raw audio for machine learning by cleaning, normalizing, and extracting features.

## 🔧 Approach & Methodology
- Loaded audio files and normalized volume.
- Trimmed silence to reduce noise.
- Extracted MFCCs and other spectral features.
- Visualized waveforms and spectrograms.

## 📈 Results & Evaluation
- Generated MFCC visualizations confirming feature extraction quality.
- Audio preprocessing reduced file size and improved clarity for modeling.

## ✅ Learning Outcomes
- Practical experience in audio feature extraction and visualization.

## 📦 Requirements
- Root `requirements.txt`
- Optional: `librosa` for feature extraction

## ▶️ How to Run
Open `audio_preprocessing.ipynb` and execute all cells.  
Place audio files in `sample_audio/`. Outputs will be saved in the `outputs/` folder.
