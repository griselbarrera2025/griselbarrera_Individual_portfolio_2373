# Sentiment & Emotion Analysis

## 🧠 Problem Statement
Classify text into sentiment categories (positive, negative, neutral) and detect fine-grained emotions.

## 🔧 Approach & Methodology
- Vectorized text using BoW and TF-IDF.
- Trained Logistic Regression for sentiment and emotion classification.
- Evaluated with precision, recall, F1-score, and confusion matrix.

## 📈 Results & Evaluation
- Sentiment classification achieved strong accuracy.
- Emotion classification varied based on label distribution.

## ✅ Learning Outcomes
- Combining sentiment and emotion detection in one pipeline.
- Feature representation vs. model capacity trade-offs.

## 📦 Requirements
- Root `requirements.txt`

## ▶️ How to Run
```bash
python sentiment_emotion.py
```
Place your dataset in `sample_data/` or update file paths in the script.  
Results will be saved in the `results/` folder.
