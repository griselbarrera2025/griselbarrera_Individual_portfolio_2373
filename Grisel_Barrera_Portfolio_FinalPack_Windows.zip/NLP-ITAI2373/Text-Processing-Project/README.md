# BBC News Classification — Text Processing Pipeline

## 🧠 Problem Statement
Classify BBC news articles into categories such as business, entertainment, politics, sport, and tech using NLP techniques.

## 🔧 Approach & Methodology
- Text cleaning: lowercasing, punctuation removal, stopword filtering, and lemmatization.
- Feature extraction using TF-IDF vectorization.
- Models tested: Logistic Regression, Random Forest, Naive Bayes.
- Evaluation with accuracy, F1-score, and confusion matrix.

## 📈 Results & Evaluation
- Best model: Logistic Regression (~91% accuracy in testing).
- Confusion matrix showed clear category separation (e.g., sport vs. tech).
- Balanced performance across all five categories.

## ✅ Learning Outcomes
- Built reproducible preprocessing and feature extraction pipelines.
- Compared classic ML classifiers for text classification.
- Interpreted accuracy, F1, and confusion matrices.

## 📦 Requirements
- Python 3.10+
- Root `requirements.txt`

## ▶️ How to Run
Open `preprocessing.ipynb` and run all cells.  
Ensure your dataset is placed in `sample_data/`. Outputs will be saved in the `outputs/` folder.
