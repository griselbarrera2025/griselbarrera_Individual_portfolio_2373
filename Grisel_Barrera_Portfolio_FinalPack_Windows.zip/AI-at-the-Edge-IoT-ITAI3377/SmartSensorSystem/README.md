# Smart IoT Sensor Alert System

## 🧠 Problem Statement
Develop an edge AI system that processes sensor data in real-time and triggers alerts when abnormal readings occur.

## 🔧 Approach & Methodology
- Loaded and preprocessed sensor CSV data.
- Implemented simple ML-based alerting.
- Designed for low-latency, low-power devices.

## 📈 Results & Evaluation
- Quick response times for simulated alerts.
- Basic anomaly detection under resource constraints.

## ✅ Learning Outcomes
- Trade-offs for deploying AI models on IoT devices.

## 📦 Requirements
- Root `requirements.txt`

## ▶️ How to Run
```bash
python iot_model.py
```
Place sample sensor files in `sensor_data/`. Alerts will be logged or printed in the console.
